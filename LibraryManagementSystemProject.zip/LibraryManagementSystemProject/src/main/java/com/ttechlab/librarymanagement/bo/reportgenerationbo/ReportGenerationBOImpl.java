package com.ttechlab.librarymanagement.bo.reportgenerationbo;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttechlab.librarymanagement.dao.BookDAO;
import com.ttechlab.librarymanagement.dto.Book;

@Service
public class ReportGenerationBOImpl implements ReportGenerationBO {

	@Autowired
	private BookDAO bookDAO;

	@Override
	public List<Book> getReport() {
		List<Book> list = bookDAO.findAll();
		Date beforeDate = new Date();
		beforeDate.setDate(1);
		beforeDate.setYear(122);
		beforeDate.setMonth(0); 
		return list.stream().filter(order -> order.getOrderDate().after(beforeDate)).collect(Collectors.toList());
	}

}
