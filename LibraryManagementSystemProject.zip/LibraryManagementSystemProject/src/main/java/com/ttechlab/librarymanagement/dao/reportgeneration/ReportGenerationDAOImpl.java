package com.ttechlab.librarymanagement.dao.reportgeneration;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class ReportGenerationDAOImpl implements ReportGenerationDAO{
   @Autowired
    DataSource dataSource;

   @Override
   public List<Map<String, Object>> getReport(String fromDate, String toDate) {
        String query = "SELECT bookId, book_date " + "FROM book" + "WHERE book_date >= :fromDate and book_date<= :toDate ";

        Map<String, String> param = new HashMap<>();
       param.put("fromDate", fromDate);
        param.put("toDate", toDate);
        return getNamedParameterJdbcTemplate().queryForList(query, param);

    }

   private NamedParameterJdbcTemplate getNamedParameterJdbcTemplate() {
        NamedParameterJdbcTemplate jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
        return jdbcTemplate;

    }



@Override
public List<Map<String, Object>> getReports() {
     String query = "SELECT book.title, book.price, category.book FROM book  INNER JOIN category ON book.category_id = category.id";

     Map<String, String> param = new HashMap<>();
  
     return getNamedParameterJdbcTemplate().queryForList(query, param);
     
     
     
     
     

 }

}
