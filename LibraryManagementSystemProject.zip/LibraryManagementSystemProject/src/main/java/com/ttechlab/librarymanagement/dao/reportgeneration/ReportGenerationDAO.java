package com.ttechlab.librarymanagement.dao.reportgeneration;

import java.util.List;
import java.util.Map;

public interface ReportGenerationDAO {

    List<Map<String, Object>> getReport(String fromDate, String toDate);

	List<Map<String, Object>> getReports();

}