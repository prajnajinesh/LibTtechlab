package com.ttechlab.librarymanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ttechlab.librarymanagement.dto.Publisher;

public interface PublisherDAO extends JpaRepository<Publisher, Long> {

}
