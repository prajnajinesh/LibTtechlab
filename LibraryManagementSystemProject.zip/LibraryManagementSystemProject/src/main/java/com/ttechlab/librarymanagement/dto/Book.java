package com.ttechlab.librarymanagement.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "book")
public class Book {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private Long isBn;

	@Column(length = 350)
	private String title;

	@Column(length = 350)
	private String edition;

	@Column(length = 300)
	private Long price;

	@ManyToOne(cascade = CascadeType.ALL)
	public Reader reader;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "publisherId")
	private Publisher publisher;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "categoryId")
	private Category category;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getIsBn() {
		return isBn;
	}

	public void setIsBn(Long isbn) {
		this.isBn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEdition() {
		return edition;
	}

	public void setEdition(String edition) {
		this.edition = edition;
	}

	public Long getPrice() {
		return price;
	}

	public void setPrice(Long price) {
		this.price = price;
	}

	public Reader getReader() {
		return reader;
	}

	public void setReader(Reader reader) {
		this.reader = reader;
	}

	public Publisher getPublisher() {
		return publisher;
	}

	public void setPublisher(Publisher publisher) {
		this.publisher = publisher;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Book [id=" + id + ", isBn=" + isBn + ", title=" + title + ", edition=" + edition + ", price=" + price
				+ ", reader=" + reader + ", publisher=" + publisher + ", category=" + category + "]";
	}

	public Date getOrderDate() {
		
		return null;
	}

}
