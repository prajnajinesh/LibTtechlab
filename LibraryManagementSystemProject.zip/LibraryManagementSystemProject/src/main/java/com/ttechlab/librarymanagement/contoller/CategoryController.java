package com.ttechlab.librarymanagement.contoller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ttechlab.librarymanagement .bo.categorybo.CategoryBO;
import com.ttechlab.librarymanagement.dto.Category;

@Controller
public class CategoryController {

	@Autowired
	private CategoryBO categoryBO;

	@PostMapping("/save-category")
	public String saveCategory(@ModelAttribute Category category) {
		categoryBO.addCategory(category);
		return "redirect:/get-category";
	}

	@GetMapping("/update-category/{id}")
	public String update(@PathVariable Long id, Model model) {
		model.addAttribute("category", categoryBO.getCategoryById(id));
		return "update-category";
	}

	@PostMapping("category/{id}")
	public String update(@PathVariable Long id, @ModelAttribute Category category) {
		// get from database
		Category categorys = categoryBO.getCategoryById(id);
		categorys.setId(category.getId());
		categorys.setBook(categorys.getBook());

		// save database
		categoryBO.saveCategory(category);
		return "redirect:/get-category";
	}

	@GetMapping(path = "/delete-category/{id}")
	public String deleteCategory(@PathVariable("id") Long id) {
		categoryBO.deleteCategory(id);
		return "redirect:/get-category";
	}

	@GetMapping("/get-category")
	public String getCategory(@RequestParam(name = "action", defaultValue = "view") String action,
			@RequestParam(name = "id", defaultValue = "-1") Long id, Model model) {
		List<Category> category = categoryBO.getAllCategory();
		model.addAttribute("category", category);
		model.addAttribute("action", action);
		if (id > 0) {
			if (category != null && category.iterator().hasNext()) {
				model.addAttribute("selectedValue", category.iterator().next());
			}
		}
		model.addAttribute("selectedValue", categoryBO.getCategoryById(id));
		return "category-management";
	}

	@GetMapping("/add-category")
	public String addbook(Model model) {
		model.addAttribute("category", new Category());
		return "add-category";
	}

	@PostMapping("/add-category")
	public String saved(@ModelAttribute Category category) {
		categoryBO.saveCategory(category);
		return "add-category";
	}

	@GetMapping("/category")

	public String addCategory() {
		return "category-home";
	}

}
