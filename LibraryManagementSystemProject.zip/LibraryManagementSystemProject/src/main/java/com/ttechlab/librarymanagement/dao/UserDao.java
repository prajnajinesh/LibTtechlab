package com.ttechlab.librarymanagement.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ttechlab.librarymanagement.dto.User;



public interface UserDao extends JpaRepository<User, Long> {
	public User findUserByUsername(String username);
		
}
