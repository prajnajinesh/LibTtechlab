package com.ttechlab.librarymanagement.bo.reportbo;

import java.util.List;

import com.ttechlab.librarymanagement.dto.Reader;
import com.ttechlab.librarymanagement.dto.Reports;

public interface ReportsBO {
	public Reports addReports(Reports reports);

	public List<Reports> getAllReports();

	public Reports getReportsById(Long id);

	public Reports updateReports(Reports book);

	public void deleteReports(Long id);

	public Reports saveReports(Reports reports);

	public Reader addReader(Reader reader);

}
