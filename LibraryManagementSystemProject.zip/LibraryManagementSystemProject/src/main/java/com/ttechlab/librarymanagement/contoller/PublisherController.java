package com.ttechlab.librarymanagement.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.ttechlab.librarymanagement.bo.publisherbo.PublisherBO;
import com.ttechlab.librarymanagement.dto.Publisher;

@Controller
public class PublisherController {

	@Autowired
	private PublisherBO publisherBO;

	@PostMapping("/save-publisher")
	public String savePublisher(@ModelAttribute Publisher publisher) {
		publisherBO.addPublisher(publisher);
		return "redirect:/get-publisher";
	}

	@PostMapping("/add-publisher")
	public ResponseEntity<Publisher> addPublisher(@RequestBody Publisher publisher) {
		Publisher newPublisher = publisherBO.addPublisher(publisher);
		return new ResponseEntity<Publisher>(newPublisher, HttpStatus.CREATED);

	}

	@GetMapping("/update-publisher/{id}")
	public String update(@PathVariable Long id, Model model) {
		model.addAttribute("publisher", publisherBO.getPublisherById(id));
		return "update-publisher";
	}

	@PostMapping("publisher/{id}")
	public String update(@PathVariable Long id, @ModelAttribute Publisher publisher) {
		// get from database
		Publisher publishers = publisherBO.getPublisherById(id);
		publishers.setId(id);
		publishers.setName(publisher.getName());
		publishers.setYearofPublication(publisher.getYearofPublication());

		// save database

		publisherBO.savePublisher(publisher);
		return "redirect:/get-publisher";
	}

	@GetMapping(path = "/delete-publisher/{id}")
	public String deletePublisher(@PathVariable("id") Long id) {
		publisherBO.deletePublisher(id);
		return "redirect:/get-publisher";
	}

	@GetMapping("/get-publisher")
	public String getPublisher(@RequestParam(name = "action", defaultValue = "view") String action,
			@RequestParam(name = "id", defaultValue = "-1") Long id, Model model) {
		List<Publisher> publisher = publisherBO.getAllPublishers();
		model.addAttribute("publisher", publisher);
		model.addAttribute("action", action);
		if (id > 0) {
			if (publisher != null && publisher.iterator().hasNext()) {
				model.addAttribute("selectedValue", publisher.iterator().next());
			}
		}
		model.addAttribute("selectedValue", publisherBO.getPublisherById(id));
		return "publisher-management";
	}

	@GetMapping("/add-publisher")
	public String addpublisher(Model model) {
		model.addAttribute("publisher", new Publisher());
		return "add-publisher";
	}

	@GetMapping("/publisher")
	public String addPublisher() {
		return "publisher-home";
	}

}
