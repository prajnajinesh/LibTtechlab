package com.ttechlab.librarymanagement.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ttechlab.librarymanagement.dto.Book;

public interface BookDAO extends JpaRepository<Book, Long> {

	Optional<Book> findById(Long id);

	List<Book> findAllByCategory(Long id);

	List<Book> findByCategoryId(Long id);

}
