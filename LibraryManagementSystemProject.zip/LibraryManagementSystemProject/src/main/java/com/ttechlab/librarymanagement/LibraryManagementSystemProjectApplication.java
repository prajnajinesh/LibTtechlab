package com.ttechlab.librarymanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementSystemProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagementSystemProjectApplication.class, args);
	}

}

