package com.ttechlab.librarymanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ttechlab.librarymanagement.dto.Reader;

public interface ReaderDAO extends JpaRepository<Reader, Long> {

}
