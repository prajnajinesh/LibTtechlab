package com.ttechlab.librarymanagement.bo.publisherbo;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttechlab.librarymanagement.dao.PublisherDAO;
import com.ttechlab.librarymanagement.dto.Publisher;

@Service
public class PublisherBOImpl implements PublisherBO {

	@Autowired
	private PublisherDAO publisherdao;

	@Override
	public Publisher addPublisher(Publisher publisher) {
		return publisherdao.save(publisher);
	}

	@Override
	public List<Publisher> getAllPublishers() {
		List<Publisher> allPublishers = publisherdao.findAll();
		if (allPublishers == null) {
			return Collections.emptyList();

		}
		return allPublishers;

	}

	@Override
	public Publisher getPublisherById(Long id) {
		Optional<Publisher> publisherById = publisherdao.findById(id);
		if (publisherById.isPresent()) {
			return publisherById.get();
		}
		return null;

	}

	@Override
	public Publisher updatePublisher(Publisher publisher) {
		return publisherdao.save(publisher);
	}

	@Override
	public void deletePublisher(Long id) {
		publisherdao.deleteById(id);
	}

	public Publisher savePublisher(Publisher publisher) {

		return publisherdao.save(publisher);
	}

	@Override
	public Publisher save(PublisherBO publisherBO) {
		return null;
	}

}
