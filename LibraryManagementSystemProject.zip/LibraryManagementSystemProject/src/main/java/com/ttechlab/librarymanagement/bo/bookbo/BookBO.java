package com.ttechlab.librarymanagement.bo.bookbo;

import java.util.List;

import com.ttechlab.librarymanagement.dto.Book;

public interface BookBO {

	public Book addBook(Book book);

	public List<Book> getAllBooks();

	public Book getBookById(Long id);

	public Book updateBook(Book book);

	public void deleteBook(Long id);

	public Book saveBook(Book book);

}
