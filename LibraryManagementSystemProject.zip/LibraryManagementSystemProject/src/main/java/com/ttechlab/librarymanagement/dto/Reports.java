 package com.ttechlab.librarymanagement.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Reports {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long regNo;

	//private Long id;

	@Column(length = 300)
	private String bookNo;

	@DateTimeFormat(pattern = "yyyy-mm-dd")
	@Column(length = 300)
	private Date returnDate;

	@DateTimeFormat(pattern = "yyyy-mm-dd")
	@Column(length = 300)
	private Date reserveDate;

	@Column(length = 300)
	@DateTimeFormat(pattern = "yyyy-mm-dd")
	private Date dueDate;

	@ManyToOne(cascade = CascadeType.ALL)
	private Reader reader;

	public Long getRegNo() {
		return regNo;
	}

	public void setRegNo(Long regNo) {
		this.regNo = regNo;
	}

//	public Long getReaderId() {
//		return id;
//	}
//
//	public void setReaderId(Long readerId) {
//		this.id = readerId;
//	}

	public String getBookNo() {
		return bookNo;
	}

	public void setBookNo(String bookNo) {
		this.bookNo = bookNo;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	public Date getReserveDate() {
		return reserveDate;
	}

	public void setReserveDate(Date reserveDate) {
		this.reserveDate = reserveDate;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}

	public Reader getReader() {
		return reader;
	}

	public void setReader(Reader reader) {
		this.reader = reader;
	}

}