package com.ttechlab.librarymanagement.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.ttechlab.librarymanagement.bo.readerbo.ReaderBO;
import com.ttechlab.librarymanagement.dto.Reader;

@Controller
public class ReaderContoller {

	@Autowired
	private ReaderBO readerBO;

	@PostMapping("/save-reader")
	public String saveReader(@ModelAttribute Reader reader) {

		readerBO.addReader(reader);
		return "redirect:/get-reader";
	}

	@PostMapping("/add-reader")
	public ResponseEntity<Reader> addReader(@RequestBody Reader reader) {
		Reader newReader = readerBO.addReader(reader);
		return new ResponseEntity<Reader>(newReader, HttpStatus.CREATED);

	}

	@GetMapping("/update-reader/{userId}")
	public String update(@PathVariable Long userId, Model model) {
		model.addAttribute("reader", readerBO.getReaderById(userId));
		return "update-reader";
	}

	@PostMapping("reader/{readerId}")
	public String update(@PathVariable Long readerId, @ModelAttribute Reader reader) {
		// get from database
		Reader readers = readerBO.getReaderById(readerId);
		readers.setReaderId(readerId);
		readers.setFirstName(readers.getFirstName());
		readers.setLastName(readers.getLastName());
		readers.setEmail(readers.getAddress());
		readers.setPhoneNo(readers.getPhoneNo());
		readers.setBooks(readers.getBooks());
		readers.setPenalty(readers.getPenalty());
		readers.setIsAdmin(readers.getIsAdmin());
		System.out.println("dddddc");
		// save database

		readerBO.saveReader(reader);
		return "redirect:/get-reader";
	}

	@GetMapping(path = "/delete-reader/{userId}")
	public String deleteReader(@PathVariable("userId") Long userId) {
		readerBO.deleteReader(userId);
		return "redirect:/get-reader";
	}

	@GetMapping("/get-reader")
	public String getReader(@RequestParam(name = "action", defaultValue = "view") String action,
			@RequestParam(name = "userId", defaultValue = "-1") Long userId, Model model) {
		List<Reader> reader = readerBO.getAllReaders();
		model.addAttribute("reader", reader);
		model.addAttribute("action", action);
		if (userId > 0) {
			if (reader != null && reader.iterator().hasNext()) {
				model.addAttribute("selectedValue", reader.iterator().next());
			}
		}
		model.addAttribute("selectedValue", readerBO.getReaderById(userId));
		return "reader-management";
	}

	@GetMapping("/add-reader")
	public String addreader(Model model) {
		model.addAttribute("reader", new Reader());
		return "add-reader";
	}

	@GetMapping("/reader")
	public String addReader() {
		return "reader-home";
	}

}
