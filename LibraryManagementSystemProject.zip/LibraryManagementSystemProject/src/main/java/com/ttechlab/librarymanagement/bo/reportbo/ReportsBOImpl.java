package com.ttechlab.librarymanagement.bo.reportbo;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttechlab.librarymanagement.dao.ReportsDAO;
import com.ttechlab.librarymanagement.dto.Reader;
import com.ttechlab.librarymanagement.dto.Reports;

@Service
public class ReportsBOImpl implements ReportsBO {

	@Autowired
	private ReportsDAO repoertsDAO;

	@Override
	public Reports addReports(Reports reports) {
		return repoertsDAO.save(reports);
	}

	@Override
	public List<Reports> getAllReports() {
		List<Reports> allReportss = repoertsDAO.findAll();
		if (allReportss == null) {
			return Collections.emptyList();

		}
		return allReportss;

	}

	@Override
	public Reports getReportsById(Long id) {
		Optional<Reports> reportsById = repoertsDAO.findById(id);
		if (reportsById.isPresent()) {
			return reportsById.get();
		}
		return null;

	}

	@Override
	public Reports updateReports(Reports reports) {
		return repoertsDAO.save(reports);
	}

	@Override
	public void deleteReports(Long id) {
		repoertsDAO.deleteById(id);
	}

	@Override
	public Reports saveReports(Reports reports) {

		return repoertsDAO.save(reports);
	}

	@Override
	public Reader addReader(Reader reader) {
		
		return null;
	}

}
