package com.ttechlab.librarymanagement.bo.readerbo;

import java.util.List;

import com.ttechlab.librarymanagement.dto.Reader;

public interface ReaderBO {
	public Reader addReader(Reader reader);

	public List<Reader> getAllReaders();

	public Reader getReaderById(Long id);

	public Reader updateReader(Reader reader);

	public void deleteReader(Long id);

	public Reader saveReader(Reader reader);

}
