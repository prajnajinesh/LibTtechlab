package com.ttechlab.librarymanagement.bo.categorybo;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttechlab.librarymanagement.dao.CategoryDAO;
import com.ttechlab.librarymanagement.dto.Book;
import com.ttechlab.librarymanagement.dto.Category;

@Service
public class CategoryBOImpl implements CategoryBO {

	@Autowired
	private CategoryDAO categoryDAO;

	@Override
	public Category addCategory(Category category) {
		return categoryDAO.save(category);
	}

	@Override
	public List<Category> getAllCategory() {
		List<Category> allCategory = categoryDAO.findAll();
		if (allCategory == null) {
			return Collections.emptyList();

		}
		return allCategory;

	}

	@Override
	public Category getCategoryById(Long id) {
		Optional<Category> categoryById = categoryDAO.findById(id);
		if (categoryById.isPresent()) {
			return categoryById.get();
		}
		return null;

	}

	@Override
	public Category updateCategory(Category category) {
		return categoryDAO.save(category);
	}

	@Override
	public void deleteCategory(Long id) {
		categoryDAO.deleteById(id);
	}

	@Override
	public Category saveCategory(Category category) {

		return categoryDAO.save(category);
	}

	@Override
	public List<Book> getAllBookByCategoryId(Long id) {

		return null;
	}

}
