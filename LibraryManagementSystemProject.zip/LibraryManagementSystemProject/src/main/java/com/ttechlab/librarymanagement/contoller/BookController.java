package com.ttechlab.librarymanagement.contoller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ttechlab.librarymanagement.bo.bookbo.BookBO;
import com.ttechlab.librarymanagement.bo.categorybo.CategoryBO;
import com.ttechlab.librarymanagement.bo.publisherbo.PublisherBO;
import com.ttechlab.librarymanagement.bo.reportbo.ReportsBO;
import com.ttechlab.librarymanagement.dto.Book;
import com.ttechlab.librarymanagement.dto.Reader;

@Controller

public class BookController {

	@Autowired
	private BookBO bookBO;

	@Autowired
	private ReportsBO reportBo;

	@Autowired
	private CategoryBO categorybo;

	@Autowired
	private PublisherBO PublisherBO;

	@PostMapping("/save-book")
	public String saveBook(@ModelAttribute Book book) {
		System.out.println("isbn ----------------- " + book.getIsBn());
		bookBO.addBook(book);
		return "redirect:/get-book";
	}

	@PostMapping("/add-book")
	public ResponseEntity<Book> addBook(@RequestBody Book book) {
		Book newBook = bookBO.addBook(book);
		System.out.println("isbn ----------------- " + book.getIsBn());
		return new ResponseEntity<Book>(newBook, HttpStatus.CREATED);

	}

	@GetMapping("/update-books/{id}")
	public String update(@PathVariable Long id, Model model) {
		model.addAttribute("book", bookBO.getBookById(id));
		return "update-books";
	}

	@PostMapping("update-books/{id}")
	public String update(@PathVariable Long id, @ModelAttribute Book book) {
		// get from database
		Book books = bookBO.getBookById(id);
		books.setId(id);
		books.setIsBn(book.getIsBn());
		books.setCategory(categorybo.getCategoryById(book.getCategory().getId()));
		books.setPublisher(PublisherBO.getPublisherById(book.getPublisher().getId()));
		books.setTitle(book.getTitle());
		books.setEdition(book.getEdition());
		books.setPrice(book.getPrice());

		// save database

		bookBO.saveBook(books);
		return "redirect:/get-book";
	}

	@GetMapping(path = "/delete-book/{id}")
	public String deleteBook(@PathVariable("id") Long id) {
		bookBO.deleteBook(id);
		return "redirect:/get-book";
	}

	@GetMapping("/get-book")
	public String getBook(@RequestParam(name = "action", defaultValue = "view") String action,
			@RequestParam(name = "id", defaultValue = "-1") Long id, Model model) {
		List<Book> book = bookBO.getAllBooks();
		book.stream().forEach(x -> System.out.println(x.getPublisher()));
		model.addAttribute("books", book);
		model.addAttribute("action", action);
		if (id > 0) {
			if (book != null && book.iterator().hasNext()) {
				model.addAttribute("selectedValue", book.iterator().next());
			}
		}
		model.addAttribute("selectedValue", bookBO.getBookById(id));
		model.addAttribute("catgeory", categorybo.getAllCategory());
		model.addAttribute("publisher", PublisherBO.getAllPublishers());
		return "book-management";
	}

	@GetMapping("/add-book")
	public String addBook(Model model) {
		model.addAttribute("book", new Book());
		model.addAttribute("categories", categorybo.getAllCategory());
		model.addAttribute("publisher", PublisherBO.getAllPublishers());

		return "add-book";
	}

	@GetMapping("/book")
	public String addBook() {
		return "book-home";
	}

	@GetMapping("/list-reader")
	public String GetReader(Model model) {
		model.addAttribute("readers", getReadersAsBooks());
		return "list-bookreader";
	} 

	private List<Reader> getReadersAsBooks() {
		return reportBo.getAllReports().stream().map(report -> report.getReader()).collect(Collectors.toList());
	}

}
