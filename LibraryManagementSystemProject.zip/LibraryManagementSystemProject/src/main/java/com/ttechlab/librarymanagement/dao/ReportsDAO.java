package com.ttechlab.librarymanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ttechlab.librarymanagement.dto.Reports;

public interface ReportsDAO extends JpaRepository<Reports, Long>{

}

