package com.ttechlab.librarymanagement.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ttechlab.librarymanagement.bo.bookbo.BookBO;
import com.ttechlab.librarymanagement.bo.categorybo.CategoryBO;
import com.ttechlab.librarymanagement.dao.BookDAO;
import com.ttechlab.librarymanagement.dao.CategoryDAO;
import com.ttechlab.librarymanagement.dto.Book;
import com.ttechlab.librarymanagement.dto.Category;

@Controller
public class HomeController {

	@Autowired
	private BookDAO bookDAO;

	@Autowired
	private CategoryBO categoryBO;

	@Autowired
	private BookBO bookBO;

	@Autowired
	private CategoryDAO categoryDAO;

	@GetMapping({ "/", "/welcome" })
	public String home(Model model) {
		return "welcome";
	}

	@GetMapping("/list-category")
	public String Books(Model model) {
		model.addAttribute("categories", categoryBO.getAllCategory());
		model.addAttribute("books", bookBO.getAllBooks());
		return "list-category";
	}

	@GetMapping(path = "/list")
	public String Getform(Model model) {
		model.addAttribute("category", new Category());
		return "list";
	}

	@GetMapping(path = "/list/")
	public String getBookByCatgeory(@RequestParam("id") Long id, Model model) {
		List<Book> books = bookDAO.findByCategoryId(id);
		model.addAttribute("books", books);
		return "list-id";
	}
	
	
	
	
}
