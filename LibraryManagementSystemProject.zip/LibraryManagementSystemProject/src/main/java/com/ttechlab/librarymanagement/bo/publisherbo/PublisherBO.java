package com.ttechlab.librarymanagement.bo.publisherbo;

import java.util.List;

import com.ttechlab.librarymanagement.dto.Publisher;

public interface PublisherBO {
	public Publisher addPublisher(Publisher publisher);

	public List<Publisher> getAllPublishers();

	public Publisher getPublisherById(Long id);

	public Publisher updatePublisher(Publisher publisher);

	public void deletePublisher(Long id);

	public Publisher save(PublisherBO publisherBO);

	public Publisher savePublisher(Publisher publisher);

}
