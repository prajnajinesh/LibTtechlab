package com.ttechlab.librarymanagement.bo.readerbo;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttechlab.librarymanagement.dao.ReaderDAO;
import com.ttechlab.librarymanagement.dto.Reader;

@Service
public class ReaderBOImpl implements ReaderBO {

	@Autowired
	private ReaderDAO readerdao;

	@Override
	public Reader addReader(Reader reader) {
		return readerdao.save(reader);
	}

	@Override
	public List<Reader> getAllReaders() {
		List<Reader> allReaders = readerdao.findAll();
		if (allReaders == null) {
			return Collections.emptyList();

		}
		return allReaders;

	}

	@Override
	public Reader getReaderById(Long userId) {
		Optional<Reader> readerById = readerdao.findById(userId);
		if (readerById.isPresent()) {
			return readerById.get();
		}
		return null;

	}

	@Override
	public Reader updateReader(Reader reader) {
		return readerdao.save(reader);
	}

	@Override
	public void deleteReader(Long id) {
		readerdao.deleteById(id);
	}

	@Override
	public Reader saveReader(Reader reader) {

		return readerdao.save(reader);
	}

}
