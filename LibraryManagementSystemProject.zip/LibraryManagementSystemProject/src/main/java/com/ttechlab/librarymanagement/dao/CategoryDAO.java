package com.ttechlab.librarymanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ttechlab.librarymanagement.dto.Category;

public interface CategoryDAO extends JpaRepository<Category, Long>{
	
	

}
