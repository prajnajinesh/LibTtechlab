package com.ttechlab.librarymanagement.bo.categorybo;

import java.util.List;

import com.ttechlab.librarymanagement.dto.Book;
import com.ttechlab.librarymanagement.dto.Category;

public interface CategoryBO {
	public Category addCategory(Category category);

	public List<Category> getAllCategory();

	public Category getCategoryById(Long id);

	public Category updateCategory(Category category);

	public void deleteCategory(Long id);

	public Category saveCategory(Category category);

	public List<Book> getAllBookByCategoryId(Long id);

}
