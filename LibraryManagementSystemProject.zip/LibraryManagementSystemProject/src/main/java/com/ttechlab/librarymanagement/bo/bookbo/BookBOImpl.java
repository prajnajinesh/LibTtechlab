package com.ttechlab.librarymanagement.bo.bookbo;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ttechlab.librarymanagement.dao.BookDAO;
import com.ttechlab.librarymanagement.dto.Book;

@Service
public class BookBOImpl implements BookBO {

	@Autowired
	private BookDAO bookdao;

	@Override
	public Book addBook(Book book) {
		return bookdao.save(book);
	}

	@Override
	public List<Book> getAllBooks() {
		List<Book> allBooks = bookdao.findAll();
		if (allBooks == null) {
			return Collections.emptyList();

		}
		return allBooks;

	}

	@Override
	public Book getBookById(Long id) {
		Optional<Book> bookById = bookdao.findById(id);
		if (bookById.isPresent()) {
			return bookById.get();
		}
		return null;

	}

	@Override
	public Book updateBook(Book book) {
		return bookdao.save(book);
	}

	@Override
	public void deleteBook(Long id) {
		bookdao.deleteById(id);
	}

	@Override
	public Book saveBook(Book book) {

		return bookdao.save(book);
	}

}
