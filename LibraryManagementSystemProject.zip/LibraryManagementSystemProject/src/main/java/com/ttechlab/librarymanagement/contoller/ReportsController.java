package com.ttechlab.librarymanagement.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.ttechlab.librarymanagement.bo.readerbo.ReaderBO;
import com.ttechlab.librarymanagement.bo.reportbo.ReportsBO;
import com.ttechlab.librarymanagement.dto.Reports;

@Controller
public class ReportsController {

	@Autowired
	private ReportsBO reportsBO;
	
	
	@Autowired
	private ReaderBO readerBo; 

	@PostMapping("/save-reports")
	public String saveReports(@ModelAttribute Reports reports) {
		reportsBO.addReports(reports);
		return "redirect:/get-reports";
	}

	@PostMapping("/add-reports")
	public ResponseEntity<Reports> addReports(@RequestBody Reports reports) {
		Reports newReports = reportsBO.addReports(reports);
		return new ResponseEntity<Reports>(newReports, HttpStatus.CREATED);

	}

	@GetMapping("/update-reports/{regNo}")
	public String update(@PathVariable Long regNo, Model model) {
		model.addAttribute("reports", reportsBO.getReportsById(regNo));
		return "update-reports";
	}

	@PostMapping("update-reports/reports/{regNo}")
	public String update(@PathVariable Long regNo, @ModelAttribute Reports reports) {
		// get from database
		Reports report = reportsBO.getReportsById(regNo);
		report.setReserveDate(reports.getReserveDate());
		report.setReturnDate(reports.getReturnDate());
		report.setDueDate(reports.getDueDate());
		report.setBookNo(reports.getBookNo());
		// save database
		reportsBO.saveReports(reports);
		return "redirect:/get-reports";
	}

	@GetMapping(path = "/delete-reports/{regNo}")
	public String deleteReports(@PathVariable("regNo") Long regNo) {
		reportsBO.deleteReports(regNo);
		return "redirect:/get-reports";
	}

	@GetMapping("/get-reports")
	public String getreports(@RequestParam(name = "action", defaultValue = "view") String action,
			@RequestParam(name = "regNo", defaultValue = "-1") Long regNo, Model model) {
		List<Reports> report = reportsBO.getAllReports();
		model.addAttribute("reports", report);
		model.addAttribute("action", action);
		if (regNo > 0) {
			if (report != null && report.iterator().hasNext()) {
				model.addAttribute("selectedValue", report.iterator().next());
			}
		}
		model.addAttribute("selectedValue", reportsBO.getReportsById(regNo));
		return "reports-management";
	}

	@GetMapping("/add-reports")
	public String addbook(Model model) {
		model.addAttribute("reports", new Reports());
		model.addAttribute("readers", readerBo.getAllReaders());
		System.out.println(readerBo.getAllReaders().size());
		return "add-reports";
	}

	@GetMapping("/reports")
	public String addReports() {
		return "reports-home";
	}

}
