package com.ttechlab.librarymanagement.bo.reportgenerationbo;

import java.util.List;

import com.ttechlab.librarymanagement.dto.Book;

public interface ReportGenerationBO {

	List<Book> getReport();

}
