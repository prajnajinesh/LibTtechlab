package com.ttechlab.LibraryManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagementSystemProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
